if echo "$MANPATH" | tr ':' '\012' | fgrep -qx /usr/lib/courier-imap/man
then
	:
else
	MANPATH="/usr/lib/courier-imap/man:$MANPATH"
	MANPATH="`echo $MANPATH | sed 's/:$//'`"
	export MANPATH
	PATH="/usr/lib/courier-imap/bin:$PATH"
	if test -w /etc
	then
		PATH="/usr/lib/courier-imap/sbin:$PATH"
	fi
	export PATH
fi

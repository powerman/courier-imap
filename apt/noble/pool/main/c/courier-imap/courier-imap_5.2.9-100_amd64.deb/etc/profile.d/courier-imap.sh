if echo "$PATH" | tr ':' '\012' | grep -Fqx "/usr/lib/courier-imap/bin"
then
	:
else
	PATH="/usr/lib/courier-imap/bin:$PATH"
	if test -w /etc
	then
		PATH="/usr/lib/courier-imap/sbin:$PATH"
	fi
	export PATH
fi
